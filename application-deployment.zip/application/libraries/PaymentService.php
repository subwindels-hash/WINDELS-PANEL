<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * PaymentService — wallet top-ups and webhook reconciliation (Session 11).
 *
 * Responsibilities:
 *   - create a PaymentTransaction (CREATED/PENDING) with idempotency
 *   - delegate to a GatewayInterface for initiation
 *   - on confirmed payment (manual approval or webhook) credit the wallet
 *     exactly once through LedgerService, recording the wallet_transaction_id
 *
 * Reconciliation is idempotent: a given (gateway, event_id) is stored once,
 * and a transaction can only move to SUCCESS once. No controller credits a
 * wallet directly.
 */
class PaymentService {

    const IDEM_SCOPE = 'payment:deposit';
    const STATUS_CREATED = 'CREATED';
    const STATUS_PENDING = 'PENDING';
    const STATUS_SUCCESS = 'SUCCESS';
    const STATUS_FAILED  = 'FAILED';

    /** Hosted card gateways the panel can route a card payment through. */
    const CARD_GATEWAY_CODES = array('paystack', 'flutterwave', 'razorpay', 'stripe');

    private $ci;

    public function __construct() {
        $this->ci =& get_instance();
        $this->ci->load->model(array(
            'Payment_transaction_model','Payment_webhook_model','Payment_event_model',
            'Wallet_model','Setting_model',
        ));
        $this->ci->load->library(array('LedgerService','EncryptionService'));
        // Gateway classes are plain (unnamespaced) library files: CI3 does not
        // autoload them and composer's PSR-4 prefix does not cover them, so
        // they must be required explicitly — `new ManualGateway` in deposit()/
        // record_webhook() fataled ("Class not found") on every live deposit.
        if (!interface_exists('GatewayInterface', false)) {
            require_once APPPATH.'libraries/GatewayInterface.php';
        }
        // Every hosted adapter extends HostedGateway, so the base class has to
        // be present before any of them is required.
        if (!class_exists('HostedGateway', false)) {
            require_once APPPATH.'libraries/HostedGateway.php';
        }
        if (!class_exists('ManualGateway', false)) {
            require_once APPPATH.'libraries/ManualGateway.php';
        }
        if (!class_exists('BlockonomicsGateway', false)) {
            require_once APPPATH.'libraries/BlockonomicsGateway.php';
        }
        if (!class_exists('FundsveraGateway', false)) {
            require_once APPPATH.'libraries/FundsveraGateway.php';
        }
        foreach (array('StripeGateway','PaypalGateway','FlutterwaveGateway','RazorpayGateway','PaystackGateway','CoinpaymentsGateway') as $gw) {
            if (!class_exists($gw, false) && is_file(APPPATH.'libraries/'.$gw.'.php')) {
                require_once APPPATH.'libraries/'.$gw.'.php';
            }
        }
    }

    /**
     * Initialise a deposit.
     *
     * @param object $user
     * @param array $input  payment_method (code), amount, currency, idempotency_key?
     * @return array{ok:bool, transaction?:object, redirect_url?:string, checkout?:array, error?:string, code?:string}
     */
    public function deposit($user, array $input) {
        $method = $this->resolve_method($input['payment_method'] ?? null);
        if (!$method) return array('ok'=>false,'error'=>'Unknown payment method','code'=>'NO_METHOD');
        if (!(int)$method->is_active) return array('ok'=>false,'error'=>'That payment method is unavailable','code'=>'METHOD_INACTIVE');

        $amount = $this->normalise_amount($input['amount'] ?? null);
        if ($amount === null) return array('ok'=>false,'error'=>'Invalid amount','code'=>'BAD_AMOUNT');
        if ($method->min_amount !== null && bccomp($amount, (string)$method->min_amount, 8) < 0)
            return array('ok'=>false,'error'=>'Minimum is '.$method->min_amount,'code'=>'AMOUNT_TOO_LOW');
        if ($method->max_amount !== null && bccomp($amount, (string)$method->max_amount, 8) > 0)
            return array('ok'=>false,'error'=>'Maximum is '.$method->max_amount,'code'=>'AMOUNT_TOO_HIGH');

        $currency = strtoupper($input['currency'] ?? marvy_base_currency());
        if (!preg_match('/^[A-Z]{3}$/', $currency)) return array('ok'=>false,'error'=>'Bad currency','code'=>'BAD_CURRENCY');

        $idem = $this->normalise_idem($input['idempotency_key'] ?? null, $user);
        if ($idem) {
            $existing = $this->ci->Payment_transaction_model->find_by_idempotency_key($idem);
            if ($existing) return array('ok'=>true,'transaction'=>$existing,'duplicate'=>true);
        }

        $fee = $this->calculate_fee($method, $amount);
        $bonus = $this->calculate_bonus($method, $amount);
        $credited = bcadd(bcsub($amount, $fee, 8), $bonus, 8);

        $public_id = marvy_public_id();
        $tx = $this->persist_transaction(array(
            'public_id'          => $public_id,
            // Fundsvera requires a >= 20-character reference that is unique per
            // business; every provider gets the same stable value so support
            // can search one column regardless of gateway.
            'internal_reference' => 'MVS-'.strtoupper($public_id),
            'provider'           => $method->code,
            'payment_method'     => $method->type ? strtolower((string)$method->type) : null,
            'initiated_at'       => gmdate('Y-m-d H:i:s'),
            'user_id'            => $user->id,
            'payment_method_id'  => $method->id,
            'amount'             => $amount,
            'fee'                => $fee,
            'bonus'              => $bonus,
            'credited_amount'    => $credited,
            'currency'           => $currency,
            'status'             => self::STATUS_CREATED,
            'idempotency_key'    => $idem,
            'metadata'           => !empty($input['note']) ? json_encode(array('note'=>$input['note'])) : null,
            'created_at'         => gmdate('Y-m-d H:i:s'),
        ));

        $this->transition($tx->id, null, self::STATUS_CREATED, 'SYSTEM', 'Initialised');

        $gateway = $this->gateway_for($method);
        $init = $gateway->initiate($tx, $user);
        if (empty($init['ok'])) {
            $this->mark_failed($tx->id, $init['error'] ?? 'Gateway error');
            return array('ok'=>false,'error'=>$init['error'] ?? 'Could not initiate payment','code'=>'GATEWAY_ERROR');
        }
        // Fundsvera's own checkout URL is a bank-transfer instructions page.
        // Always land the customer on our deposit page instead: it offers a
        // hosted card gateway when one is configured, shows the account
        // details we parsed, and keeps the Fundsvera checkout link as the
        // "open secure checkout" option. Jumping straight to the Fundsvera
        // link is how a customer who asked for card payment ends up staring at
        // a transfer page with no card option.
        if (strtolower((string)$method->code) === 'fundsvera') {
            $init['redirect_url'] = null;
        }
        $status = $init['status'] ?? self::STATUS_PENDING;
        // Hosted gateways echo the reference we gave them on their callback,
        // so store it now: without it the webhook has nothing to match on and
        // a paid deposit sits unreconciled.
        $post_init = array();
        if (!empty($init['provider_tx_id'])) {
            $post_init['provider_tx_id'] = substr((string)$init['provider_tx_id'], 0, 128);
        }
        // Keep the provider's own checkout payload (link, crypto address, coin
        // amount, expiry). A customer who closes the tab mid-payment can then
        // resume from Deposits instead of starting a second deposit — and
        // support can see exactly what the customer was shown.
        if (!empty($init['checkout']) || !empty($init['redirect_url'])) {
            $meta = json_decode((string)$tx->metadata, true);
            $meta = is_array($meta) ? $meta : array();
            $meta['checkout'] = array_merge(
                is_array($init['checkout'] ?? null) ? $init['checkout'] : array(),
                array('redirect_url' => $init['redirect_url'] ?? null)
            );
            $post_init['metadata'] = json_encode($meta, JSON_UNESCAPED_SLASHES);
        }
        if ($post_init) {
            $this->ci->Payment_transaction_model->update_status($tx->id, $post_init);
        }
        $this->transition($tx->id, self::STATUS_CREATED, $status, 'GATEWAY', 'Initiated');
        $tx = $this->ci->Payment_transaction_model->find_by_id($tx->id);

        return array(
            'ok' => true,
            'transaction' => $tx,
            'redirect_url' => $init['redirect_url'] ?? null,
            'checkout' => $init['checkout'] ?? null,
        );
    }

    /**
     * Confirm a transaction and credit the wallet once.
     *
     * @param object $tx        the payment transaction
     * @param string $source    SYSTEM|ADMIN|WEBHOOK
     * @param string|null $provider_tx_id
     */
    public function confirm($tx, $source = 'SYSTEM', $provider_tx_id = null) {
        if (!$tx || $tx->status === self::STATUS_SUCCESS) return array('ok'=>true,'duplicate'=>true,'transaction'=>$tx);
        if (!in_array($tx->status, array(self::STATUS_CREATED, self::STATUS_PENDING), true)) {
            return array('ok'=>false,'error'=>'Transaction cannot be confirmed in '.$tx->status,'code'=>'BAD_STATE');
        }
        $wallet = $this->ci->Wallet_model->for_user($tx->user_id);
        $credited = $tx->credited_amount !== null ? (string)$tx->credited_amount : (string)$tx->amount;
        $idem = 'payment:credit:'.($tx->idempotency_key ?: $tx->public_id);

        $this->ci->db->trans_start();
        $credit = $this->ci->ledgerservice->credit(
            $wallet->id, $credited, 'DEPOSIT', 'PaymentTransaction', $tx->public_id, $idem,
            array('fee'=>(string)$tx->fee, 'bonus'=>(string)$tx->bonus, 'tx_id'=>$tx->public_id)
        );
        if (empty($credit['ok'])) {
            $this->ci->db->trans_complete();
            return array('ok'=>false,'error'=>$credit['error'] ?? 'Could not credit wallet','code'=>'CREDIT_FAILED');
        }
        // Find the wallet transaction we just created.
        $wt = $this->ci->db->where('idempotency_key', $idem)->get('wallet_transactions')->row();
        $update = array(
            'status' => self::STATUS_SUCCESS,
            'wallet_transaction_id' => $wt ? $wt->id : null,
            'verified_at' => gmdate('Y-m-d H:i:s'),
            'paid_at' => gmdate('Y-m-d H:i:s'),
        );
        if ($provider_tx_id) $update['provider_tx_id'] = substr((string)$provider_tx_id, 0, 128);
        $this->ci->Payment_transaction_model->update_status($tx->id, $update);
        $this->transition($tx->id, $tx->status, self::STATUS_SUCCESS, $source, 'Confirmed');
        $this->ci->db->trans_complete();

        // The customer asked for this money to arrive; tell them it has.
        // Outside the transaction and never fatal — the credit is already
        // committed and a mail problem must not undo it.
        try {
            $this->ci->load->library('NotificationService');
            // load->library() succeeding does not guarantee the property is
            // there (a test double, or a loader that resolved it under another
            // name); reading it blind raises a warning try/catch cannot see.
            if (isset($this->ci->notificationservice)) {
                $wallet_now = $this->ci->Wallet_model->for_user($tx->user_id);
                $this->ci->notificationservice->notify(
                    $tx->user_id, 'payment.credited',
                    marvy_money($credited, $tx->currency).' has been added to your wallet.',
                    array('reference' => $tx->public_id, 'url' => 'dashboard/wallet/deposits/'.$tx->public_id),
                    array(
                        'amount'  => marvy_money($credited, $tx->currency),
                        // The wallet may hold a different currency than the
                        // deposit; show the balance in what it actually holds.
                        'balance' => marvy_money($wallet_now->balance ?? '0',
                            $wallet_now->currency ?? $tx->currency),
                    )
                );
            }
        } catch (Throwable $e) {
            log_message('error', 'deposit notification failed for '.$tx->public_id.': '.$e->getMessage());
        }

        // A confirmed deposit may be the event that qualifies a referral.
        // Outside the transaction and never fatal: the deposit has already
        // succeeded, and a referral bookkeeping problem must not roll it back.
        $this->referral_event($tx->user_id, 'FIRST_DEPOSIT');

        return array('ok'=>true,'transaction'=>$this->ci->Payment_transaction_model->find_by_id($tx->id));
    }

    /**
     * Notify the referral system, without ever affecting the caller.
     *
     * Its own method so an early return here cannot skip the calling method's
     * return value. load->library() succeeding does not guarantee the property
     * exists — under a test double, or a loader that resolved it under another
     * name, reading it blind raises a warning a try/catch cannot see.
     */
    private function referral_event($user_id, $event) {
        try {
            $this->ci->load->library('ReferralService');
            if (!isset($this->ci->referralservice)) return;
            $this->ci->referralservice->record_event($user_id, $event);
        } catch (Throwable $e) {
            log_message('error', 'referral '.$event.' hook failed: '.$e->getMessage());
        }
    }

    /** Mark a transaction failed (terminal). */
    public function mark_failed($tx_id, $reason = null) {
        $tx = $this->ci->Payment_transaction_model->find_by_id($tx_id);
        if (!$tx || in_array($tx->status, array(self::STATUS_SUCCESS, self::STATUS_FAILED), true)) return;
        $this->ci->Payment_transaction_model->update_status($tx->id,
            array('failed_at' => gmdate('Y-m-d H:i:s')));
        $this->transition($tx->id, $tx->status, self::STATUS_FAILED, 'SYSTEM', $reason);
    }

    /**
     * Record and process an incoming webhook (idempotent on gateway+event_id).
     *
     * @return array{ok:bool, already_seen?:bool, transaction?:object, error?:string}
     */
    public function record_webhook($gateway_type, $raw_body, array $headers) {
        // Gateways with a real adapter verify and parse their own callbacks.
        // Anything else goes through the generic HMAC envelope, which is
        // fail-closed: no configured secret means the event is stored but no
        // money moves.
        $gateway = in_array($gateway_type, $this->implemented_gateways(), true)
            ? $this->gateway_for_code($gateway_type)
            : null;

        $sig_ok = $gateway
            ? $gateway->verify_webhook($raw_body, $headers)
            : $this->verify_generic_signature($gateway_type, $raw_body, $headers);

        if ($gateway instanceof BlockonomicsGateway) {
            // Blockonomics reports progress in the query string, so its parser
            // needs the headers too.
            $event = $gateway->parse_event($raw_body, $headers);
        } elseif ($gateway) {
            $event = $gateway->parse_event($raw_body);
        } else {
            $event = $this->parse_generic_event($raw_body);
        }

        $id = $this->ci->Payment_webhook_model->record_once(
            $gateway_type,
            $event['event_id'] ?? null,
            $raw_body,
            $sig_ok,
            $event['type'] ?? null
        );
        if ($id === false) {
            return array('ok'=>true,'already_seen'=>true); // duplicate, do not reprocess
        }

        // Only process when signature is valid AND the event indicates success.
        if ($sig_ok === false) {
            $this->ci->db->where('id', $id)->update('payment_webhooks',
                array('processed'=>1,'processed_at'=>gmdate('Y-m-d H:i:s'),'error'=>'invalid signature'));
            return array('ok'=>false,'error'=>'Invalid signature');
        }
        // null means "no secret configured, cannot verify": store the event for
        // the operator to inspect but never move money on it.
        if ($sig_ok === null) {
            $this->ci->db->where('id', $id)->update('payment_webhooks', array(
                'processed' => 1,
                'processed_at' => gmdate('Y-m-d H:i:s'),
                'error' => 'unverified: no webhook secret configured for '.$gateway_type,
            ));
            return array('ok'=>true,'unverified'=>true);
        }

        return $this->process_event($id, $event);
    }

    /**
     * Re-run a callback that was stored, verified, but never finished.
     *
     * Replaying the raw body through record_webhook() cannot work: webhook
     * signatures live in HTTP headers we did not keep, so re-verification
     * would fail and a genuine, already-verified event would be closed as
     * "invalid signature". This picks up from the point verification had
     * already reached — which is exactly what a retry needs, and why both the
     * reconciliation sweep and the admin "reprocess" button use it.
     *
     * @param object $row a payment_webhooks row with signature_valid = 1
     */
    public function reprocess_stored_webhook($row) {
        if (!$row || (int)$row->signature_valid !== 1) {
            return array('ok' => false, 'error' => 'That event never passed signature verification.');
        }

        $gateway_type = strtolower((string)$row->gateway_type);
        $gateway = in_array($gateway_type, $this->implemented_gateways(), true)
            ? $this->gateway_for_code($gateway_type)
            : null;

        $event = $gateway
            ? ($gateway instanceof BlockonomicsGateway
                ? $gateway->parse_event((string)$row->payload, array())
                : $gateway->parse_event((string)$row->payload))
            : $this->parse_generic_event((string)$row->payload);

        // Reopen the row so the outcome of this attempt is what gets stored.
        $this->ci->db->where('id', $row->id)->update('payment_webhooks',
            array('processed' => 0, 'error' => null));

        return $this->process_event((int)$row->id, $event);
    }

    /**
     * Act on a verified, parsed gateway event: match the deposit and credit it
     * exactly once, recording the outcome on the webhook row.
     */
    private function process_event($id, array $event) {
        $terminal = strtolower($event['status'] ?? '');

        // A confirmed-but-short payment is a real event that must be visible to
        // staff, and must never credit as though it were complete.
        if ($terminal === 'underpaid') {
            $this->ci->db->where('id', $id)->update('payment_webhooks', array(
                'processed' => 1,
                'processed_at' => gmdate('Y-m-d H:i:s'),
                'error' => 'underpaid: amount received is less than the amount quoted',
            ));
            return array('ok'=>true,'underpaid'=>true);
        }

        if (!in_array($terminal, array('success','succeeded','completed','paid','approved'), true)) {
            $this->ci->db->where('id', $id)->update('payment_webhooks', array('processed'=>1,'processed_at'=>gmdate('Y-m-d H:i:s')));
            return array('ok'=>true,'ignored'=>true);
        }

        // Resolution order matters. An adapter that can name the transaction
        // directly (a crypto callback resolves it from the receive address it
        // issued) is authoritative and is tried first: matching on
        // provider_tx_id alone can land on a *different, older* transaction
        // that happens to carry the same id, and silently no-op because that
        // one is already SUCCESS.
        $tx = null;
        if (!empty($event['metadata']['payment_transaction_id'])) {
            $tx = $this->ci->Payment_transaction_model->find_by_id(
                (int) $event['metadata']['payment_transaction_id']
            );
        }
        if (!$tx && !empty($event['provider_tx_id'])) {
            $tx = $this->ci->Payment_transaction_model->find_by_provider_tx($event['provider_tx_id']);
        }
        if (!$tx && !empty($event['metadata']['idempotency_key'])) {
            $tx = $this->ci->Payment_transaction_model->find_by_idempotency_key($event['metadata']['idempotency_key']);
        }
        if (!$tx && !empty($event['metadata']['wallet_user_id'])) {
            // A standing Fundsvera virtual-account payment: no deposit was
            // open, but the gateway resolved the account to its owner. Open a
            // deposit for that customer and let confirm() settle it below —
            // this is the documented behaviour of the VA webhook ("virtual
            // account funded" ⇒ credit that customer), not a bonus feature.
            $tx = $this->open_virtual_account_deposit($event);
        }
        if (!$tx) {
            // Accepted and logged, but there is nothing to reconcile — the
            // event references no transaction of ours. Treat it as processed
            // so the gateway stops retrying; the error column flags it for the
            // operator.
            $this->ci->db->where('id', $id)->update('payment_webhooks', array(
                'processed' => 1,
                'processed_at' => gmdate('Y-m-d H:i:s'),
                'error' => 'no matching transaction',
            ));
            return array('ok'=>true,'unmatched'=>true,'error'=>'No matching transaction');
        }

        $res = $this->confirm($tx, 'WEBHOOK', $event['provider_tx_id'] ?? null);
        if (empty($res['ok'])) {
            // Transient processing failure (e.g. the ledger write rolled
            // back). Leave the row UNPROCESSED so the gateway's retry — and
            // the reconciliation sweep over unprocessed() — re-runs it, and
            // flag it retryable so the controller answers 503 (which real
            // gateways retry) instead of a swallowed 200.
            $this->ci->db->where('id', $id)->update('payment_webhooks', array(
                'payment_transaction_id' => $tx->id,
                'error' => substr('retryable: '.($res['error'] ?? 'confirmation failed'), 0, 250),
            ));
            return array('ok'=>false,'retryable'=>true,'error'=>$res['error'] ?? 'Payment processing failed');
        }
        $this->ci->db->where('id', $id)->update('payment_webhooks', array(
            'payment_transaction_id' => $tx->id,
            'processed' => 1,
            'processed_at' => gmdate('Y-m-d H:i:s'),
        ));
        return $res;
    }

    /**
     * Open a deposit for a payment that arrived in a standing virtual account.
     *
     * Fundsvera's virtual-account webhook names only the account and the
     * amount — there was no deposit row to begin with. This creates one in
     * the PENDING state carrying exactly what the webhook reported, and the
     * caller immediately confirms it, so a VA payment follows the same
     * ledger-guaranteed exactly-once path as any other deposit:
     *
     *   - the webhook row is deduped on (gateway, event_id = trx_ref) before
     *     this is ever reached, and
     *   - the transaction itself is keyed on an idempotency key derived from
     *     the provider's trx_ref, which also becomes the ledger credit key —
     *   so a redelivery or an admin reprocess cannot double-credit.
     *
     * The provider's cut (`settlement_amount`/`fee` in the payload) is
     * recorded in metadata; the customer is credited what they actually paid
     * (`amount_paid`).
     *
     * @return object|null the PENDING transaction, or null when the event
     *                     carries no usable owner/amount (stays unmatched)
     */
    private function open_virtual_account_deposit(array $event) {
        $user_id = (int)($event['metadata']['wallet_user_id'] ?? 0);
        $amount = $event['amount'] ?? null;
        if ($user_id <= 0 || !is_numeric($amount) || bccomp((string)$amount, '0', 8) <= 0) {
            return null;
        }
        $amount = number_format((float)$amount, 8, '.', '');

        // One deposit per provider transaction, forever — even if the webhook
        // row were lost, this key refuses a second credit for the same trx_ref.
        $idem = 'va-'.substr((string)($event['event_id'] ?? ''), 0, 120);
        if ($idem === 'va-') $idem = null;
        if ($idem !== null) {
            $existing = $this->ci->Payment_transaction_model->find_by_idempotency_key($idem);
            if ($existing) return $existing;
        }

        $public_id = marvy_public_id();
        // The table requires a payment_method_id; the seeded fundsvera row is
        // the one this credit belongs to. A missing row (operator deleted it)
        // still credits — id 0 keeps the money path alive and the deposit
        // findable, rather than dropping a confirmed payment over bookkeeping.
        $method = $this->resolve_method('fundsvera');
        if (!$method) {
            log_message('error', 'fundsvera: no fundsvera payment_methods row — '
                .'virtual-account credits will carry payment_method_id 0');
        }
        $meta = array('virtual_account' => array(
            'account_number'    => $event['metadata']['virtual_account_no'] ?? null,
            'customer_email'    => $event['metadata']['customer_email'] ?? null,
            'settlement_amount' => $event['metadata']['settlement_amount'] ?? null,
            'provider_fee'      => $event['metadata']['fee'] ?? null,
        ));
        $this->persist_transaction(array(
            'public_id'          => $public_id,
            'internal_reference' => 'MVS-'.strtoupper($public_id),
            'provider'           => 'fundsvera',
            'payment_method'     => 'virtual_account',
            'initiated_at'       => gmdate('Y-m-d H:i:s'),
            'user_id'            => $user_id,
            'payment_method_id'  => $method ? (int)$method->id : 0,
            'amount'             => $amount,
            'fee'                => '0.00000000',
            'bonus'              => '0.00000000',
            'credited_amount'    => $amount,
            'currency'           => strtoupper((string)($event['currency'] ?? 'NGN')),
            'status'             => self::STATUS_PENDING,
            'idempotency_key'    => $idem,
            'metadata'           => json_encode($meta, JSON_UNESCAPED_SLASHES),
            'created_at'         => gmdate('Y-m-d H:i:s'),
        ));
        $tx = $this->ci->Payment_transaction_model->find_by_id($this->ci->db->insert_id());
        if (!$tx) return null;

        // Audit-trail entry only (PENDING → PENDING writes no status change).
        $this->transition($tx->id, self::STATUS_PENDING, self::STATUS_PENDING,
            'WEBHOOK', 'Paid into the customer\'s bank transfer account');
        return $tx;
    }

    /**
     * Create (or fetch) a customer's standing Fundsvera bank account.
     *
     * The controller-facing entry point for the docs' "Virtual Account
     * (Create)" — kept beside the other gateway routing so neither the JSON
     * API nor the dashboard can drift from the configured adapter.
     */
    public function virtual_account($user) {
        $method = $this->resolve_method('fundsvera');
        if (!$method) {
            return array('ok' => false, 'error' => 'Bank transfer payments are unavailable',
                'code' => 'NO_METHOD');
        }
        if (!(int)$method->is_active) {
            return array('ok' => false, 'error' => 'That payment method is unavailable',
                'code' => 'METHOD_INACTIVE');
        }
        $gateway = $this->gateway_for($method);
        if (!method_exists($gateway, 'create_virtual_account')) {
            return array('ok' => false, 'error' => 'Bank accounts are not available for this provider',
                'code' => 'UNSUPPORTED');
        }
        return $gateway->create_virtual_account($user);
    }

    /* -------------------------------------------------------------- */

    public function calculate_fee($method, $amount) {
        $pct = (float)$method->fee_percent;
        $fixed = (float)$method->fee_fixed;
        $fee = bcadd(bcmul($amount, (string)($pct/100), 8), (string)$fixed, 8);
        return bccomp($fee, '0', 8) > 0 ? number_format((float)$fee, 8, '.', '') : '0.00000000';
    }

    public function calculate_bonus($method, $amount) {
        $pct = (float)$method->bonus_percent;
        if ($pct <= 0) return '0.00000000';
        return number_format((float)bcmul($amount, (string)($pct/100), 8), 8, '.', '');
    }

    private function resolve_method($code) {
        if (!$code) return null;
        return $this->ci->db->where('code', $code)->get('payment_methods')->row();
    }

    private function gateway_for($method) {
        return $this->gateway_for_code($method->code, $method);
    }

    /**
     * The adapter that serves a payment-method row.
     *
     * Public because reconciliation has to ask a gateway what happened to a
     * deposit whose webhook never arrived, and building the adapter itself
     * would duplicate the routing table.
     */
    public function adapter_for($method) {
        return $this->gateway_for_code($method->code ?? '', $method);
    }

    /**
     * The adapter that handles a payment-method code.
     *
     * Only adapters that are actually implemented and wired are routed here.
     * Everything else falls back to ManualGateway, which marks the deposit
     * PENDING for admin review — a deposit that waits for a human is always
     * safer than one handed to an untested integration.
     */
    private function gateway_for_code($code, $method_row = null) {
        $code = strtolower((string)$code);
        switch ($code) {
            case 'blockonomics':
            case 'btc':
                return new BlockonomicsGateway($method_row);
            case 'fundsvera':
                return new FundsveraGateway($method_row);
            case 'stripe':
                return new StripeGateway($method_row);
            case 'paypal':
                return new PaypalGateway($method_row);
            case 'flutterwave':
                return new FlutterwaveGateway($method_row);
            case 'razorpay':
                return new RazorpayGateway($method_row);
            case 'paystack':
                return new PaystackGateway($method_row);
            case 'coinpayments':
                return new CoinpaymentsGateway($method_row);
            case 'manual':
            default:
                return new ManualGateway($method_row);
        }
    }

    /**
     * Payment methods a customer can actually pay with right now.
     *
     * `is_active` is the operator's intent; being *configured* is whether the
     * adapter has credentials. Offering a method that will fail at the last
     * step — after the customer has typed an amount and pressed Pay — is worse
     * than not offering it, so an active-but-unconfigured gateway is hidden
     * from Add funds and flagged in the admin console instead.
     */
    public function payable_methods() {
        $rows = $this->ci->db->where('is_active', 1)->order_by('sorting', 'ASC')
            ->get('payment_methods')->result();

        $out = array();
        foreach ($rows as $row) {
            if ($this->method_is_configured($row)) $out[] = $row;
        }
        return $out;
    }

    /**
     * The first configured hosted card gateway for a card fallback.
     *
     * Fundsvera is a bank-transfer provider; its checkout URL is a transfer
     * instructions page, not a card form. To still let a Fundsvera deposit be
     * paid by card, the deposit page can hand the exact same transaction to a
     * hosted card gateway (Paystack / Flutterwave / Razorpay / Stripe). This
     * helper answers which one is actually ready — configured — so the page
     * never offers a card button that fails at the first click.
     *
     * @return object|null a payment_methods row for the card gateway
     */
    public function card_method_for_deposit() {
        // A configured card gateway is enough for the Fundsvera fallback even
        // when its own method row is not shown on Add funds — the operator has
        // supplied working credentials, and the fallback is the only way a
        // customer can pay that deposit by card.
        foreach (self::CARD_GATEWAY_CODES as $code) {
            $row = $this->resolve_method($code);
            if ($row && $this->method_is_configured($row)) return $row;
        }
        return null;
    }

    /**
     * Start (or resume) a card checkout against an existing pending deposit.
     *
     * The deposit was created as a Fundsvera bank-transfer payment. This does
     * not create a second deposit: it asks a hosted card gateway for a
     * checkout URL using the SAME transaction, so a successful card webhook
     * credits the same deposit exactly once. The card URL is stored on the
     * transaction metadata so a customer who closes the tab can resume it.
     *
     * @param object $tx   an existing PaymentTransaction
     * @param object $user the signed-in customer
     * @return array{ok:bool, redirect_url?:string, checkout?:array, method?:object, error?:string, code?:string}
     */
    public function card_checkout($tx, $user) {
        if (!$tx) {
            return array('ok' => false, 'error' => 'No deposit to pay for', 'code' => 'NO_TRANSACTION');
        }
        if ($tx->status === self::STATUS_SUCCESS) {
            return array('ok' => false, 'error' => 'This deposit is already completed', 'code' => 'ALREADY_COMPLETE');
        }
        if ($tx->status === self::STATUS_FAILED) {
            return array('ok' => false, 'error' => 'This deposit has already failed — start a new deposit',
                'code' => 'ALREADY_FAILED');
        }
        if (!in_array($tx->status, array(self::STATUS_CREATED, self::STATUS_PENDING), true)) {
            return array('ok' => false, 'error' => 'This deposit cannot be paid now', 'code' => 'BAD_STATE');
        }

        // Reuse an already-created card checkout rather than opening a second
        // one on every page refresh.
        $meta = json_decode((string)$tx->metadata, true);
        if (is_array($meta) && !empty($meta['card_checkout']['redirect_url'])) {
            return array(
                'ok'           => true,
                'redirect_url' => (string)$meta['card_checkout']['redirect_url'],
                'checkout'     => $meta['card_checkout'],
            );
        }

        $method = $this->card_method_for_deposit();
        if (!$method) {
            return array('ok' => false,
                'error' => 'Card payment is not available yet. Enable Paystack, Flutterwave, '
                    .'Razorpay or Stripe in Admin → Settings, or use bank transfer.',
                'code' => 'CARD_UNAVAILABLE');
        }

        $gateway = $this->gateway_for($method);
        $init = $gateway->initiate($tx, $user);
        if (empty($init['ok'])) {
            return array('ok' => false,
                'error' => $init['error'] ?? 'Could not start the card payment',
                'code' => $init['code'] ?? 'CARD_INIT_FAILED');
        }

        $this->store_card_checkout($tx, $init);
        return array(
            'ok'           => true,
            'redirect_url' => $init['redirect_url'] ?? null,
            'checkout'     => $init['checkout'] ?? null,
            'method'       => $method,
        );
    }

    /** Persist the card checkout URL on the transaction so it can be resumed. */
    private function store_card_checkout($tx, array $init) {
        $meta = json_decode((string)$tx->metadata, true);
        $meta = is_array($meta) ? $meta : array();
        $checkout = is_array($init['checkout'] ?? null) ? $init['checkout'] : array();
        $meta['card_checkout'] = array_merge(
            $checkout,
            array(
                'redirect_url' => $init['redirect_url'] ?? null,
                'provider'     => $checkout['provider'] ?? '',
            )
        );
        $this->ci->Payment_transaction_model->update_status($tx->id, array(
            'metadata'   => json_encode($meta, JSON_UNESCAPED_SLASHES),
            'updated_at' => gmdate('Y-m-d H:i:s'),
        ));
    }

    /**
     * Finish a hosted payment whose customer has come back to us.
     *
     * Most hosted gateways complete the charge on their own side and their
     * return visit is a formality - for those this is a quiet no-op. PayPal is
     * the exception: the buyer's approval only signs the order, and PayPal
     * charges the instrument when WE capture, so the return is where the money
     * actually moves. Everything here goes through the same idempotent
     * confirm() a webhook uses, so a page refresh, a racing
     * PAYMENT.CAPTURE.COMPLETED webhook, or the reconciliation sweep cannot
     * credit the wallet twice.
     *
     * @param object $tx an open payment transaction
     * @return array{ok:bool, noop?:bool, transaction?:object, error?:string}
     */
    public function settle_hosted_return($tx) {
        if (!$tx || !in_array($tx->status, array(self::STATUS_CREATED, self::STATUS_PENDING), true)) {
            return array('ok' => true, 'noop' => true);
        }

        $code = strtolower((string)$tx->provider);
        if (!in_array($code, $this->implemented_gateways(), true)) {
            return array('ok' => true, 'noop' => true);
        }

        $gateway = $this->gateway_for_code($code);
        if (!method_exists($gateway, 'capture')) {
            return array('ok' => true, 'noop' => true);
        }

        // The provider's own key for this checkout (PayPal's order id), stored
        // at initiation. Without it there is nothing to capture.
        $meta = json_decode((string)$tx->metadata, true);
        $checkout = is_array($meta['checkout'] ?? null) ? $meta['checkout'] : array();
        $order_id = $checkout['order_id'] ?? null;
        if (!$order_id) return array('ok' => true, 'noop' => true);

        $cap = $gateway->capture($order_id);
        if (empty($cap['ok'])) {
            // Deliberately NOT mark_failed: a transient blip must not close a
            // deposit the customer may still complete, and reconciliation
            // re-checks every open order on its next tick anyway.
            log_message('error', $code.': could not capture the approved order for '
                .$tx->public_id.': '.($cap['error'] ?? 'unknown'));
            return array('ok' => false, 'error' => $cap['error'] ?? 'The payment could not be completed yet.');
        }

        // What the provider captured must cover what the deposit was opened
        // for. The order was created for exactly this amount, so a mismatch
        // means something is wrong somewhere - flagged for staff, never
        // credited short.
        if (isset($cap['amount']) && $cap['amount'] !== null
                && bccomp((string)$cap['amount'], (string)$tx->amount, 8) < 0) {
            log_message('error', $code.': capture for '.$tx->public_id.' arrived short - '
                .($cap['amount'] ?? '?').' against '.$tx->amount.'; left for staff');
            return array('ok' => false, 'error' => 'The payment that arrived is short of the deposit amount.');
        }

        if (($cap['status'] ?? '') === 'SUCCESS') {
            return $this->confirm($tx, 'GATEWAY', $cap['provider_tx_id'] ?? null);
        }
        if (($cap['status'] ?? '') === 'FAILED') {
            $this->mark_failed($tx->id, 'The provider reports the payment as '
                .strtolower((string)($cap['detail'] ?? 'failed')).'.');
            return array('ok' => false, 'error' => 'The payment was not completed.');
        }
        return array('ok' => false, 'error' => 'The payment is still processing.');
    }

    /**
     * Whether the adapter behind a payment method can take a payment.
     *
     * Manual bank transfer needs no credentials — a human reconciles it — so
     * it is always considered configured.
     */
    public function method_is_configured($method) {
        $code = strtolower((string)$method->code);
        if (!in_array($code, $this->implemented_gateways(), true)) return true;

        $gateway = $this->gateway_for_code($code, $method);
        if (!method_exists($gateway, 'is_configured')) return true;

        try {
            return (bool)$gateway->is_configured();
        } catch (Throwable $e) {
            log_message('error', 'could not read '.$code.' configuration: '.$e->getMessage());
            return false;
        }
    }

    /**
     * Whether this method's adapter needs API credentials at all.
     *
     * Manual bank transfer does not: a human reads the bank statement and
     * approves the deposit. Reporting it as "not configured" would send an
     * operator hunting for keys that do not exist.
     */
    public function method_needs_credentials($method) {
        $code = strtolower((string)$method->code);
        if (!in_array($code, $this->implemented_gateways(), true)) return false;
        return method_exists($this->gateway_for_code($code, $method), 'is_configured');
    }

    /**
     * Payment-method codes whose adapter is wired and trusted to verify its
     * own callbacks.
     *
     * Every adapter here calls the provider's real API and verifies the
     * provider's real signature. An adapter with no credentials configured
     * answers null from verify_webhook() — "cannot verify" — which stores the
     * event for the operator without moving money, instead of discarding a
     * genuine callback or crediting an unverified one.
     */
    public function implemented_gateways() {
        return array('manual', 'blockonomics', 'fundsvera',
                     'paystack', 'flutterwave', 'stripe', 'paypal', 'razorpay', 'coinpayments');
    }

    private function persist_transaction(array $data) {
        $this->ci->db->insert('payment_transactions', $data);
        return $this->ci->Payment_transaction_model->find_by_id($this->ci->db->insert_id());
    }

    private function transition($tx_id, $from, $to, $source, $reason = null) {
        // Persist the new state first, then append to the (append-only) event
        // log. Writing only the log would leave the transaction stuck in its
        // previous status forever.
        if ($from !== $to) {
            $this->ci->Payment_transaction_model->update_status($tx_id, array(
                'status'     => $to,
                'updated_at' => gmdate('Y-m-d H:i:s'),
            ));
        }
        $this->ci->db->insert('payment_events', array(
            'payment_transaction_id' => $tx_id,
            'from_status' => $from,
            'to_status' => $to,
            'source' => $source,
            'reason' => $reason,
            'created_at' => gmdate('Y-m-d H:i:s'),
        ));
    }

    /**
     * Verify an HMAC-SHA256 signature header against the configured secret.
     *
     * @return bool|null true/false when we can decide, null when no secret is
     *                   configured (the caller must not process the event).
     */
    private function verify_generic_signature($gateway_type, $raw_body, array $headers) {
        $sig = null;
        foreach ($headers as $name => $value) {
            if (stripos((string)$name, 'signature') !== false) { $sig = trim((string)$value); break; }
        }
        // An unsigned callback is always rejected.
        if ($sig === null || $sig === '') return false;

        $secret = $this->ci->Setting_model->get('payments.'.$gateway_type.'.webhook_secret');
        if (!$secret) $secret = getenv('MARVYSOCIALS_'.strtoupper($gateway_type).'_WEBHOOK_SECRET') ?: null;
        if (!$secret) return null;

        $expected = hash_hmac('sha256', (string)$raw_body, (string)$secret);
        // Strip an optional "sha256=" / "v1=" prefix before comparing.
        if (strpos($sig, '=') !== false) {
            $parts = explode('=', $sig, 2);
            if (ctype_alnum($parts[0])) $sig = $parts[1];
        }
        return hash_equals($expected, $sig);
    }

    /** Parse a plain JSON webhook envelope into the normalised event shape. */
    private function parse_generic_event($raw_body) {
        $data = json_decode((string)$raw_body, true);
        if (!is_array($data)) return array('event_id'=>null,'type'=>'unknown');
        $pick = function(array $keys) use ($data) {
            foreach ($keys as $k) {
                if (isset($data[$k]) && $data[$k] !== '') return $data[$k];
            }
            return null;
        };
        return array(
            'event_id'       => $pick(array('id','event_id','eventId')),
            'type'           => $pick(array('type','event','event_type')) ?: 'unknown',
            'provider_tx_id' => $pick(array('provider_tx_id','transaction_id','reference','txn_id')),
            'status'         => $pick(array('status','state','result')),
            'amount'         => $pick(array('amount','value')),
            'currency'       => $pick(array('currency','currency_code')),
            'metadata'       => isset($data['metadata']) && is_array($data['metadata']) ? $data['metadata'] : array(),
        );
    }

    private function normalise_amount($v) {
        if ($v === null || $v === '' || !is_numeric($v)) return null;
        $f = (float)$v;
        if ($f <= 0 || !is_finite($f)) return null;
        return number_format($f, 8, '.', '');
    }

    private function normalise_idem($key, $user) {
        if (!$key) return 'deposit:'.$user->id.':'.marvy_public_id();
        $clean = preg_replace('/[^a-zA-Z0-9._\-]/', '', (string)$key);
        return substr(self::IDEM_SCOPE.':'.$clean, 0, 128);
    }
}
