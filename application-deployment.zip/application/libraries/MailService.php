<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * MailService — renders email_templates and enqueues the result into email_queue.
 *
 * Actual delivery is performed by a cron worker (Session 16) — the web/auth path
 * must never block on SMTP. In non-production environments the queued payload is
 * also written to the log when MAIL_LOG=1, which is how local/dev reads the
 * verify/reset links.
 */
class MailService {

    private $ci;

    public function __construct() {
        $this->ci =& get_instance();
        $this->ci->load->model('Setting_model');
    }

    /**
     * Enqueue a templated email.
     *
     * @param string $to
     * @param string $template_key  e.g. "auth.verify_email"
     * @param array  $variables     merged into {{placeholders}}
     * @param string $to_name
     * @return bool
     */
    public function enqueue_template($to, $template_key, array $variables = array(), $to_name = null) {
        $row = $this->ci->db->where('template_key', $template_key)
            ->where('is_active', 1)->get('email_templates')->row();
        if (!$row) {
            log_message('error', "mail: missing template {$template_key}");
            return false;
        }

        $variables = array_merge($this->global_variables(), $variables);
        $subject = $this->interpolate($row->subject, $variables);
        $html    = $this->interpolate($row->body_html, $variables);
        $text    = $row->body_text ? $this->interpolate($row->body_text, $variables) : self::readable_text($html);

        return $this->enqueue_raw($to, $subject, $html, $text, $to_name, $template_key);
    }

    /**
     * Queue the standard password-reset message.
     *
     * Keeping URL construction and template selection here prevents the two
     * entry points (self-service Forgot password and Admin → Customers) from
     * drifting. The admin action previously issued a valid token and then
     * claimed it had emailed it without ever inserting an email_queue row.
     *
     * @param object $user  User row with email and username
     * @param string $token Signed reset token from AuthService
     * @return bool
     */
    public function enqueue_password_reset($user, $token) {
        if (!is_object($user) || empty($user->email) || empty($user->username)
            || !is_string($token) || trim($token) === '') {
            log_message('error', 'mail: refused incomplete password-reset message');
            return false;
        }

        return $this->enqueue_template(
            $user->email,
            'auth.password_reset',
            array(
                'username'  => $user->username,
                'reset_url' => site_url('reset-password/' . $token),
            ),
            $user->username
        );
    }

    /**
     * Enqueue a raw (already-rendered) email.
     */
    public function enqueue_raw($to, $subject, $body_html, $body_text = null,
                                 $to_name = null, $template_key = null) {
        $ok = (bool) $this->ci->db->insert('email_queue', array(
            'to_email'     => strtolower(trim($to)),
            'to_name'      => $to_name,
            'subject'      => $subject,
            'body_html'    => $body_html,
            'body_text'    => $body_text,
            'template_key' => $template_key,
            'status'       => 'QUEUED',
            'attempts'     => 0,
            'scheduled_at' => gmdate('Y-m-d H:i:s'),
            'created_at'   => gmdate('Y-m-d H:i:s'),
        ));

        if ($ok && env_bool('MAIL_LOG')) {
            $this->write_mail_log("queued to {$to} <{$subject}>\n".self::readable_text($body_html));
        }
        return $ok;
    }

    /**
     * Flatten HTML to text WITHOUT throwing away the links.
     *
     * A bare strip_tags() keeps the anchor text and discards the href, so
     * "<a href="…/reset-password/TOKEN">Reset password</a>" collapses to the
     * words "Reset password" and the token — the only thing the message exists
     * to carry — is gone. That silently emptied both the plain-text alternative
     * part of every email and the logged copy of a reset link.
     *
     * Each link is rendered as "text (url)". Angle brackets are deliberately
     * NOT used as the delimiter: "<https://…>" is indistinguishable from a tag
     * to strip_tags(), which would remove the URL again on the very next line.
     */
    public static function readable_text($html) {
        $out = (string)$html;
        $out = preg_replace_callback(
            '/<a\b[^>]*href\s*=\s*["\']([^"\']*)["\'][^>]*>(.*?)<\/a>/is',
            function ($m) {
                $href = trim($m[1]);
                $text = trim(strip_tags($m[2]));
                if ($href === '') return $text;
                // Don't print the URL twice when it is already the link text.
                if ($text === '' || $text === $href) return $href;
                return $text.' ('.$href.')';
            },
            $out
        );
        // Keep the line structure the reader expects from block elements.
        $out = preg_replace('/<(br|\/p|\/div|\/li|\/tr|\/h[1-6])\b[^>]*>/i', "\n", $out);
        $out = strip_tags($out);
        $out = html_entity_decode($out, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        // Collapse the blank-line pileup the tag removal leaves behind.
        $out = preg_replace('/[ \t]+/', ' ', $out);
        $out = preg_replace('/\n{3,}/', "\n\n", $out);
        return trim($out);
    }

    /**
     * Write an outbound-mail payload somewhere an operator can actually read.
     *
     * This deliberately does NOT go through log_message('info'). CI3 grades
     * levels ERROR=1, DEBUG=2, INFO=3 and only writes a level whose number is
     * <= the configured threshold — and config/config.php sets that threshold
     * to 1 in production and 2 with APP_DEBUG on. INFO is 3, so it is above
     * the threshold in BOTH cases: every 'info' line this class ever wrote was
     * discarded before it reached a file.
     *
     * That is what made the `log` transport a black hole. deliver() reported
     * ok=true, the queue row was marked SENT, and the message existed nowhere
     * at all — no inbox, no log, nothing to retry — which is exactly how a
     * password-reset link goes missing without leaving a trace.
     *
     * So the payload is appended to its own file (storage/logs/mail.log, which
     * needs no threshold to be readable), and log_message('error') is the
     * fallback when that path is not writable — 'error' being the one level
     * this panel always emits.
     *
     * @return bool whether the payload was persisted somewhere
     */
    private function write_mail_log($message) {
        $line = '['.gmdate('Y-m-d H:i:s').' UTC] '.$message."\n\n";

        $path = null;
        try {
            if (class_exists('Env') || is_file(APPPATH.'core/Env.php')) {
                require_once APPPATH.'core/Env.php';
                $paths = Env::writable_paths();
                if (!empty($paths['logs'])) $path = rtrim($paths['logs'], '/').'/mail.log';
            }
        } catch (Throwable $e) {
            $path = null;
        }

        if ($path !== null) {
            $dir = dirname($path);
            if (!is_dir($dir)) @mkdir($dir, 0775, true);
            if (@file_put_contents($path, $line, FILE_APPEND | LOCK_EX) !== false) {
                return true;
            }
        }

        // Last resort: the only level this panel's threshold always writes.
        log_message('error', 'mail[log] '.$message);
        return false;
    }

    /**
     * Deliver one queued message (called by the email_queue cron worker).
     *
     * Transport is chosen from settings, falling back to VP_MAIL_DRIVER in
     * .env so a fresh deployment sends mail without an admin first visiting a
     * settings screen: `mail` hands off to PHP's mail() (what a cPanel account
     * has working out of the box), `smtp` uses CI3's email library against the
     * configured server, `log` writes the payload to the log (the default in
     * dev, and what the verify/reset links are read from locally). The queue
     * row itself is managed by the worker — this method only attempts delivery
     * and reports the outcome.
     *
     * @return array{ok:bool, transport?:string, error?:string}
     */
    public function deliver($mail) {
        if (!$mail || empty($mail->to_email)) {
            return array('ok'=>false, 'error'=>'missing recipient');
        }
        $transport = $this->transport();

        if ($transport === 'log' || env_bool('MAIL_LOG')) {
            $written = $this->write_mail_log(sprintf(
                "to=%s subject=%s\n%s",
                $mail->to_email, $mail->subject,
                // Flatten the HTML (link-preserving) in preference to the
                // stored body_text: rows queued before migration 041 have a
                // text part whose URLs were stripped, and this logged copy is
                // the operator's last resort for a reset link that never
                // arrived — it has to contain the actual URL.
                trim((string)$mail->body_html) !== ''
                    ? self::readable_text((string)$mail->body_html)
                    : (string)$mail->body_text
            ));
            if ($transport === 'log') {
                // Only claim success when the payload is actually readable
                // somewhere. A 'log' transport that cannot write is a message
                // that vanished, and reporting ok=true would mark the queue
                // row SENT and destroy the last copy of a reset link.
                return $written
                    ? array('ok'=>true, 'transport'=>'log')
                    : array('ok'=>false, 'transport'=>'log',
                            'error'=>'the log transport could not write the message anywhere',
                            'hint'=>'storage/logs is not writable, so nothing was delivered and nothing '
                                .'was recorded. Fix the permissions, or set Admin → Settings → Email → '
                                .'Transport to "mail" (cPanel sendmail) to send real email.');
            }
        }

        if ($transport !== 'smtp' && $transport !== 'mail') {
            return array('ok'=>false, 'error'=>"unknown mail transport '{$transport}'");
        }

        try {
            $this->ci->load->library('email');
            $this->prime_message($mail);

            if (!$this->ci->email->send(false)) {
                // CI3's SMTP client records the whole conversation in its
                // debug buffer — including the server's greeting banner, which
                // is always the FIRST entry. Reporting "the first line" (the
                // old behaviour) told the operator the mail server said hello,
                // and nothing about why the send failed. Read the buffer back
                // and surface the actual failure plus a cPanel-oriented hint.
                // The summary is captured BEFORE any retry — a retry clears
                // the debug buffer for its own transcript.
                $summary = $this->smtp_failure_summary();

                $swap = $this->retry_alternate_crypto($mail);
                if (is_array($swap) && !empty($swap['ok'])) return $swap;
                if (is_array($swap) && !empty($swap['hint'])) {
                    $summary['hint'] = trim((string)$summary['hint'].' '.$swap['hint']);
                }

                return array(
                    'ok'        => false,
                    'transport' => $transport,
                    'error'     => $summary['reason'],
                    'hint'      => $summary['hint'],
                );
            }
            return array('ok'=>true, 'transport'=>$transport);
        } catch (Exception $e) {
            return array('ok'=>false, 'transport'=>$transport, 'error'=>$e->getMessage());
        }
    }

    /**
     * Load one queued message onto the CI3 email instance: a clean slate,
     * the pinned greeting name, sender identity, recipient and bodies.
     * Used for the first attempt and again after a crypto-swap retry (which
     * re-opens the connection on the same instance).
     */
    private function prime_message($mail) {
        $this->ci->email->clear(true);
        // Pin the protocol to the transport this panel actually resolved.
        //
        // config/email.php builds the library's protocol from VP_MAIL_DRIVER
        // alone, while transport() lets the admin-editable `mail_transport`
        // setting win. When they disagree the panel used to send through the
        // .env protocol while REPORTING the settings one: an operator who
        // switched Admin → Settings → Email → Transport to "smtp" and entered
        // their cPanel credentials still had every message handed to PHP
        // mail(), which many shared hosts silently blackhole — mail() returns
        // true, the queue row goes SENT, and the reset link is never
        // delivered. Setting it here makes the reported transport the one that
        // is used.
        $transport = $this->transport();
        if ($transport === 'smtp' || $transport === 'mail') {
            if (method_exists($this->ci->email, 'set_protocol')) {
                $this->ci->email->set_protocol($transport);
            } else {
                $this->ci->email->protocol = $transport;
            }
        }
        // Greet the server with the panel's real domain, never the stock
        // 'localhost.localdomain' a cron request has for SERVER_NAME:
        // cPanel Exim setups with strict HELO checks reject or mislog a
        // junk greeting name, and that is the class of failure the
        // "503 HELO or EHLO required" queue errors came from.
        if (property_exists($this->ci->email, 'helo_host')) {
            $this->ci->email->helo_host = $this->helo_host();
        }
        // DB settings win (admin-editable); .env supplies the initial
        // defaults (VP_MAIL_FROM_ADDRESS / VP_MAIL_FROM_NAME).
        $from_email = class_exists('Env') ? (string) Env::get('MAIL_FROM_ADDRESS', '') : '';
        $from_name  = class_exists('Env') ? (string) Env::get('MAIL_FROM_NAME', '') : '';
        $this->ci->email->from(
            $this->ci->Setting_model->get('mail_from_email', $from_email !== '' ? $from_email : 'no-reply@marvy.local'),
            $this->ci->Setting_model->get('mail_from_name',  $from_name  !== '' ? $from_name  : 'MarvySocials')
        );
        $this->ci->email->to($mail->to_email);
        $this->ci->email->subject($mail->subject);
        $this->ci->email->message($mail->body_html);
        if (!empty($mail->body_text)) $this->ci->email->set_alt_message($mail->body_text);
    }

    /**
     * One bounded retry with the OTHER encryption/port pairing, only when
     * the first attempt died at the handshake in a way that means "this
     * port speaks a different protocol" (MY_Email::handshake_failure).
     *
     * The failure that motivated it — the queue logging
     *
     *     hello: hello: Unable to send email using PHP SMTP. Your server
     *     might not be configured to send mail using this method.
     *
     * is what port 465 (implicit SSL) does to a client configured for
     * 587/tls: TCP connects, the server waits for a TLS ClientHello, every
     * cleartext greeting is ignored or reset. cPanel gives the operator
     * BOTH pairings (465⇔ssl, 587⇔tls) and mis-picking one is the single
     * most common shared-hosting mail failure — so the panel swaps once,
     * and when the swap lands it says exactly what to persist. Auth and
     * relay failures (server answered 4xx/5xx: SMTP was reached fine) never
     * trigger a swap.
     *
     * @return array|null  a deliver()-shaped success result when the swap
     *                     delivered the message; array('ok'=>false,'hint'=>…)
     *                     when the swap was attempted and also refused;
     *                     null when no swap applies (not an SMTP handshake
     *                     failure, or the email class cannot be re-armed)
     */
    private function retry_alternate_crypto($mail) {
        $email = $this->ci->email;
        if (!is_object($email)
            || !property_exists($email, 'handshake_failure')
            || !method_exists($email, 'reset_connection')
            || (string)$email->handshake_failure === ''
            || $email->protocol !== 'smtp') {
            return null;
        }
        $diagnosis = (string)$email->handshake_failure;

        list($crypto, $port, $label, $env_pair) =
            $this->alternate_crypto_pairing($email->smtp_crypto, (int)$email->smtp_port);

        $email->smtp_crypto = $crypto;
        $email->smtp_port   = $port;
        $email->reset_connection();
        $this->prime_message($mail);

        if (!$email->send(false)) {
            log_message('error',
                "mail: {$diagnosis} on the configured pairing and the {$label} fallback both failed");
            return array(
                'ok'   => false,
                'hint' => 'The panel also retried with '.$label
                    .' and the server still dropped the handshake — so the fix is the host, port '
                    .'and encryption settings themselves (or a firewall on outbound SMTP), not a '
                    .'temporary failure.',
            );
        }

        log_message('error',
            "mail: delivered via the {$label} fallback after the configured pairing failed ({$diagnosis}) — persist {$env_pair} in .env");

        return array(
            'ok'        => true,
            'transport' => 'smtp',
            'note'      => 'SMTP refused the configured pairing at the handshake ('.$diagnosis
                .') and only accepted the message after switching to '.$label
                .'. Persist '.$env_pair.' in .env so the panel does not rely on the fallback.',
        );
    }

    /**
     * The opposite encryption/port pairing of the configured one. Port and
     * crypto travel together in every cPanel mail doc: 465 is implicit SSL,
     * 587 is STARTTLS — sending either protocol at the other's port is the
     * silent-drop failure. An unset crypto picks the pairing the port is
     * NOT the conventional home of (587 → try implicit SSL on 465 first).
     *
     * @return array{0:string,1:int,2:string,3:string}
     *         crypto, port, human label, the .env pair to persist
     */
    private function alternate_crypto_pairing($crypto, $port) {
        $crypto = strtolower(trim((string)$crypto));
        if ($crypto === 'ssl') {
            return array('tls', 587, 'STARTTLS (tls) on port 587', 'VP_MAIL_CRYPTO=tls and VP_MAIL_PORT=587');
        }
        if ($crypto === 'tls') {
            return array('ssl', 465, 'implicit SSL (ssl) on port 465', 'VP_MAIL_CRYPTO=ssl and VP_MAIL_PORT=465');
        }
        return $port === 465
            ? array('tls', 587, 'STARTTLS (tls) on port 587', 'VP_MAIL_CRYPTO=tls and VP_MAIL_PORT=587')
            : array('ssl', 465, 'implicit SSL (ssl) on port 465', 'VP_MAIL_CRYPTO=ssl and VP_MAIL_PORT=465');
    }

    /**
     * Turn CI3's debug buffer into an operator-actionable answer.
     *
     * Every SMTP exchange is appended to the buffer, so on failure it reads
     * something like:
     *
     *   220-server315.web-hosting.com ESMTP Exim 4.99.5 #2 ...   ← banner
     *   hello: 250-server315.web-hosting.com ...                 ← command echo
     *   Failed to authenticate password. Response: 535 5.7.8 ... ← the failure
     *
     * The banner is NOT the error — it proves the connection opened. The real
     * reason is the last entry that is not a 2xx/3xx exchange (banner, echoed
     * command, or a DATA reply the server accepted).
     *
     * @return array{reason:string, hint:string}
     */
    public function smtp_failure_summary() {
        $raw = (string) $this->ci->email->print_debugger(array());
        // Every <pre>/<br> boundary is a LINE boundary. CI3 wraps greeting
        // echoes in <pre> WITHOUT a trailing <br />, so strip_tags alone
        // glues the next entry onto them — that merging is precisely why a
        // failed send pastes as one long line:
        // "hello: hello: Unable to send email using PHP SMTP. …".
        $raw = str_ireplace(array('<br />', '<br>', '<pre>', '</pre>'), "\n", $raw);
        $raw = strip_tags($raw);
        $lines = preg_split('/\r\n|\r|\n/', $raw);

        // Pass 1 — MY_Email's own stage diagnosis ("mail: no-smtp-banner — …")
        // names both the failure and the fix. It outranks anything the wire
        // produced, including the server's own reply codes, because a refusal
        // of STARTTLS (server: "454", library: "the following SMTP error was
        // encountered") is a symptom; the diagnosis says what it MEANS.
        $reason = '';
        foreach ((array) $lines as $line) {
            $line = trim($line);
            if (stripos($line, 'mail: ') === 0) {
                $reason = $line;
                break;
            }
        }

        if ($reason === '') {
            $generic_tail = '';
            $silent_hello = false;

            // Pass 2 — the wire transcript.
            foreach ((array) $lines as $line) {
                $line = trim($line);
                if ($line === '' || $this->is_smtp_exchange($line)) continue;

                // "hello:" with nothing after it is a greeting the server
                // dropped silently (connection closed in reply to EHLO/HELO)
                // — the signature behind the classic "hello: hello: Unable
                // to send email using PHP SMTP" report. Remember it for the
                // fallback reason below.
                if (preg_match('/^hello:\s*$/i', $line)) {
                    $silent_hello = true;
                    continue;
                }

                // CI3 always ends a failed send with "Unable to send email
                // using PHP SMTP. Your server might not be configured to send
                // mail using this method." — or, when the email language
                // file never loaded, the raw lang key "email_send_failure_smtp".
                // It is the tail of EVERY SMTP failure and explains none of
                // them — never let it outrank a real line.
                if (stripos($line, 'unable to send email using php') === 0
                    || preg_match('/^email_send_failure_(smtp|phpmail|sendmail)$/i', $line)) {
                    $generic_tail = $line;
                    continue;
                }

                // The server's own reply is the truth: "from: 503 HELO or EHLO
                // required" explains more than CI3's generic lang keys do, so
                // prefer the first server reply carrying a failure code.
                if (preg_match('/^[a-z_]*:?\s*[45]\d{2}[\s-]/i', $line)) {
                    $reason = $line;
                    break;
                }
                $reason = $line; // fallback: keep the last meaningful line
            }

            if ($reason === '') {
                if ($silent_hello) {
                    $reason = 'The mail server closed the connection without answering the SMTP '
                        .'greeting (empty reply to EHLO/HELO).';
                } elseif ($generic_tail !== '') {
                    $reason = $generic_tail;
                } else {
                    $reason = 'The SMTP server rejected the message without a usable explanation.';
                }
            }
        }

        // What the operator should actually check, mapped from the failure.
        $lower = function_exists('mb_strtolower') ? mb_strtolower($reason) : strtolower($reason);
        $hint  = '';
        if (strpos($lower, 'authenticate password') !== false
            || strpos($lower, 'smtp_auth_pw') !== false
            || preg_match('/\b535\b/', $reason)) {
            $hint = 'Authentication failed. Check VP_MAIL_USER / VP_MAIL_PASS in .env — on cPanel the username is the full '
                .'email address, and if the account has two-step login on, generate an App Password '
                .'(cPanel → Email Accounts → App Passwords) and use that instead of the account password.';
        } elseif (strpos($lower, 'failed to send auth login') !== false
            || strpos($lower, 'smtp_auth_un') !== false) {
            $hint = 'The server rejected the AUTH LOGIN handshake. Try VP_MAIL_CRYPTO=ssl with VP_MAIL_PORT=465 '
                .'(or tls with 587) in .env — some cPanel hosts only accept one of the two.';
        } elseif (strpos($lower, 'helo or ehlo required') !== false
            || strpos($lower, 'bad sequence') !== false
            || (preg_match('/\b503\b/', $reason) && strpos($lower, 'helo') !== false)) {
            $hint = 'The mail server processed MAIL FROM without accepting the greeting. The panel now greets '
                .'with the panel\'s own domain (VP_MAIL_HELO, or the site URL host) and falls back to a plain HELO '
                .'when EHLO is refused. If this error still appears, switch the transport to "mail" in '
                .'Admin → Settings → Email → Transport (cPanel\'s sendmail needs no SMTP host, port or credentials '
                .'and works out of the box), or check that the SMTP host/port are the mail-submission endpoint from '
                .'cPanel → Email Accounts → Connect Devices.';
        } elseif (strpos($lower, 'no-smtp-banner') !== false
            || strpos($lower, 'silent-greeting') !== false
            || strpos($lower, 'closed the connection without answering') !== false) {
            // The port-and-crypto mispairing — the "hello: hello: Unable to
            // send email using PHP SMTP" report. retry_alternate_crypto()
            // already tried the other pairing once; the hint states the rule
            // so the operator fixes the configured one.
            $hint = 'The server answered TCP but never spoke SMTP back — port and encryption are '
                .'mispaired. They must travel together: port 587 with VP_MAIL_CRYPTO=tls, port 465 '
                .'with VP_MAIL_CRYPTO=ssl (cPanel → Email Accounts → Connect Devices lists both '
                .'pairings). The bearer symptom of this is "hello: hello: Unable to send email '
                .'using PHP SMTP" in the queue log.';
        } elseif (strpos($lower, 'starttls-refused') !== false
            || (strpos($lower, 'starttls') !== false
                && (strpos($lower, '454') !== false
                    || strpos($lower, 'refused') !== false
                    || strpos($lower, 'not available') !== false))) {
            $hint = 'This host does not accept STARTTLS on that port — it expects implicit SSL '
                .'instead: set VP_MAIL_CRYPTO=ssl with VP_MAIL_PORT=465. (Or switch the transport '
                .'to "mail": cPanel\'s sendmail needs no SMTP host, port or credentials at all.)';
        } elseif (strpos($lower, 'tls-negotiation-failed') !== false) {
            $hint = 'The server accepted STARTTLS but the TLS handshake itself failed. Check that '
                .'VP_MAIL_HOST is exactly the mail host cPanel names for the account and that '
                .'VP_MAIL_PORT=587 pairs with VP_MAIL_CRYPTO=tls.';
        } elseif (strpos($lower, 'starttls') !== false
            || strpos($lower, 'unable to connect') !== false
            || strpos($lower, 'error: #(') !== false
            || strpos($lower, 'no_socket') !== false) {
            $hint = 'Could not open a usable connection. Check VP_MAIL_HOST, VP_MAIL_PORT and VP_MAIL_CRYPTO in .env: '
                .'cPanel usually offers 465/ssl or 587/tls on the mail host (the host in your cPanel banner, e.g. '
                .'server315.web-hosting.com, or mail.yourdomain.com).';
        } elseif (strpos($lower, 'hostname') !== false && strpos($lower, 'smtp') !== false) {
            $hint = 'No SMTP host is configured — set VP_MAIL_HOST in .env (cPanel → Email Accounts shows the hostname).';
        } elseif (preg_match('/\b[45]\d{2}\b/', $reason)
            || strpos($lower, 'relay') !== false
            || strpos($lower, 'sender') !== false
            || strpos($lower, 'domain') !== false
            || strpos($lower, 'not local') !== false) {
            $hint = 'The server refused the message — usually because the From address (Settings → From address) is not '
                .'on the same domain as the SMTP account. cPanel accounts can normally only relay mail for their own '
                .'domain; use a From address on that domain or ask the host to allow the sender.';
        }
        return array('reason' => $reason, 'hint' => $hint);
    }

    /**
     * True when a debug-buffer line is a successful exchange (server banner or
     * a per-command echo such as "hello: 250-..."), not a failure. 4xx/5xx
     * replies are failures even though they look like the same "220 ..." shape.
     */
    private function is_smtp_exchange($line) {
        if (preg_match('/^(\d{3})[- ]/', $line, $m)) {
            return (int) $m[1] < 400;
        }
        if (preg_match('/^[a-z_]+:\s+(\d{3})[- ]/i', $line, $m)) {
            return (int) $m[1] < 400;
        }
        return false;
    }

    /**
     * The transport delivery will use: settings first, then VP_MAIL_DRIVER,
     * defaulting to `log` so a fresh install never silently drops mail into a
     * misconfigured SMTP server.
     *
     * Public because the admin mail-queue screen has to tell the operator
     * which transport their test will actually go through — "it worked" means
     * nothing if it worked by writing to a log file.
     */
    public function transport() {
        require_once APPPATH.'core/Env.php';
        $default = strtolower((string)Env::get('MAIL_DRIVER', 'log'));
        if (!in_array($default, array('log', 'smtp', 'mail'), true)) $default = 'log';

        $configured = strtolower((string)$this->ci->Setting_model->get('mail_transport', $default));
        return in_array($configured, array('log', 'smtp', 'mail'), true) ? $configured : $default;
    }

    /**
     * The name the SMTP client greets the server with (EHLO/HELO argument).
     *
     * Resolved from VP_MAIL_HELO (or the admin setting `mail_helo`), then the
     * panel's own host from the base URL. Under cron there is no
     * $_SERVER['SERVER_NAME'], and stock CI3 would greet with
     * "localhost.localdomain" — a name strict cPanel Exim configurations
     * reject or mis-log, which is the class of failure behind the production
     * "503 HELO or EHLO required" queue errors. Empty string = let the client
     * decide.
     */
    private function helo_host() {
        require_once APPPATH.'core/Env.php';
        $env = strtolower(trim((string)Env::get('MAIL_HELO', '')));
        if ($env !== '') return $env;

        $setting = strtolower(trim((string)$this->ci->Setting_model->get('mail_helo', '')));
        if ($setting !== '') return $setting;

        $host = parse_url(rtrim((string)site_url(''), '/'), PHP_URL_HOST);
        if (is_string($host) && $host !== '') return strtolower($host);
        return '';
    }

    /**
     * Send a test message immediately, bypassing the queue.
     *
     * The operator is waiting for an answer: queueing would report success for
     * a message the SMTP server has not seen yet, which is exactly the thing
     * they are trying to find out.
     */
    public function send_test($to) {
        $site = $this->ci->Setting_model->get('site_name', 'MarvySocials');
        $mail = (object)array(
            'to_email'  => strtolower(trim((string)$to)),
            'to_name'   => null,
            'subject'   => $site.' — test message',
            'body_html' => '<p>This is a test message from '.htmlspecialchars($site).'.</p>'
                          .'<p>If you are reading it, outbound email works. Sent '
                          .gmdate('Y-m-d H:i:s').' UTC via the '.$this->transport().' transport.</p>',
            'body_text' => 'Test message from '.$site.'. Sent '.gmdate('Y-m-d H:i:s').' UTC.',
        );

        $res = $this->deliver($mail);
        $res['transport'] = $res['transport'] ?? $this->transport();
        return $res;
    }

    /* -------------------------------------------------------------- */

    private function global_variables() {
        return array(
            'site_name'     => $this->ci->Setting_model->get('site_name', 'MarvySocials'),
            'site_url'      => rtrim(base_url(), '/'),
            'support_email' => $this->ci->Setting_model->get('support_email', 'support@marvy.local'),
            'year'          => gmdate('Y'),
        );
    }

    private function interpolate($template, array $vars) {
        $out = (string)$template;
        foreach ($vars as $key => $value) {
            if (is_scalar($value) || $value === null) {
                $out = str_replace('{{' . $key . '}}', (string)$value, $out);
            }
        }
        // Strip any unresolved placeholders rather than leaking them.
        return preg_replace('/\{\{\s*[a-zA-Z0-9_]+\s*\}\}/', '', $out);
    }
}
