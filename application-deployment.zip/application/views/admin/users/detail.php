<?php defined('BASEPATH') OR exit('No direct script access allowed');
$perms = $permissions ?? array();
$has   = function ($k) use ($perms) { return in_array('*', $perms, true) || in_array($k, $perms, true); };
$csrf  = function () { return '<input type="hidden" name="'.htmlspecialchars($this->security->get_csrf_token_name())
    .'" value="'.htmlspecialchars($this->security->get_csrf_hash()).'" readonly>'; };

$can_edit  = $has('users.edit');
$can_role  = $has('staff.manage');
$can_price       = $has('pricing.manage');
$can_money       = $has('wallets.adjust');
$can_impersonate = $has('users.impersonate');
$self            = (int)$current_user->id === (int)$user->id;

$status_badge = function ($s) {
    $map = array('ACTIVE'=>'badge-success','SUSPENDED'=>'badge-warning','BANNED'=>'badge-danger','PENDING'=>'badge-default');
    return $map[strtoupper((string)$s)] ?? 'badge-default';
};
// One nonce per render: the adjustment form's idempotency key. Re-submitting
// the same rendered page cannot pay the customer twice.
$nonce = bin2hex(random_bytes(8));
?>
<div class="row justify-between mb-4" style="align-items:flex-start;flex-wrap:wrap;gap:.75rem">
  <div>
    <a class="text-xs muted" href="<?=site_url('admin/customers')?>">← Customers</a>
    <h2 class="mb-0" style="font-size:1.4rem;font-weight:600">
      <?=htmlspecialchars((string)$user->username)?>
      <span class="badge <?=$status_badge($user->status)?>"><?=htmlspecialchars((string)$user->status)?></span>
    </h2>
    <p class="muted text-sm">
      <?=htmlspecialchars((string)$user->email)?>
      <?php if (!empty($user->user_code)): ?>
      · <span title="Six-digit account number — the customer can sign in and quote support with this">ID
        <span class="mono"><?=htmlspecialchars((string)$user->user_code)?></span></span>
      <?php endif; ?>
      · <span class="mono text-xs"><?=htmlspecialchars((string)$user->public_id)?></span>
      · joined <?=htmlspecialchars(date('M j, Y', strtotime($user->created_at)))?>
    </p>
  </div>
  <div class="text-right">
    <div class="muted text-xs">Wallet balance</div>
    <div style="font-size:1.5rem;font-weight:600" class="mono">
      <?=marvy_money($user->wallet->balance, $user->wallet->currency)?>
    </div>
  </div>
</div>

<?php if ($self): ?>
<div class="alert alert-info mb-4">
  This is your own account. Role and status changes are disabled here — ask another admin.
</div>
<?php endif; ?>
<?php if (!empty($is_last_admin)): ?>
<div class="alert alert-warning mb-4">
  This is the only active super admin. It cannot be demoted or suspended until someone else is promoted.
</div>
<?php endif; ?>

<div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(15rem,1fr));gap:.75rem" class="mb-4">
  <div class="card">
    <div class="muted text-xs">Lifetime deposited</div>
    <div class="mono" style="font-size:1.1rem"><?=marvy_money($user->wallet->total_deposited, $user->wallet->currency)?></div>
  </div>
  <div class="card">
    <div class="muted text-xs">Lifetime spent</div>
    <div class="mono" style="font-size:1.1rem"><?=marvy_money($user->wallet->total_spent, $user->wallet->currency)?></div>
  </div>
  <div class="card">
    <div class="muted text-xs">Role</div>
    <div style="font-size:1.1rem"><?=htmlspecialchars((string)$user->role)?></div>
  </div>
  <div class="card">
    <div class="muted text-xs">Last login</div>
    <div class="text-sm"><?=$user->last_login_at ? htmlspecialchars(date('M j, Y H:i', strtotime($user->last_login_at))) : 'never'?></div>
  </div>
</div>

<div class="card mb-4">
  <h3 style="font-size:1rem;font-weight:600" class="mb-3">Account</h3>
  <div class="row" style="gap:.5rem;flex-wrap:wrap">

    <?php if ($can_edit && !$self): ?>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/status')?>"
          class="row" style="gap:.35rem;align-items:flex-end">
      <?=$csrf()?>
      <label class="field"><span class="label">Status</span>
        <select class="select" name="status">
          <?php foreach ($statuses as $s): ?>
            <option value="<?=htmlspecialchars($s)?>" <?=$user->status === $s ? 'selected' : ''?>>
              <?=htmlspecialchars($s)?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="field"><span class="label">Reason</span>
        <input class="input" name="reason" placeholder="Optional, kept in the audit log">
      </label>
      <button class="btn btn-secondary btn-sm" type="submit">Apply</button>
    </form>
    <?php endif; ?>

    <?php if ($can_role && !$self): ?>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/role')?>"
          class="row" style="gap:.35rem;align-items:flex-end">
      <?=$csrf()?>
      <label class="field"><span class="label">Role</span>
        <select class="select" name="role">
          <?php foreach ($roles as $r): ?>
            <option value="<?=htmlspecialchars($r)?>" <?=$user->role === $r ? 'selected' : ''?>>
              <?=htmlspecialchars($r)?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <button class="btn btn-secondary btn-sm" type="submit">Change role</button>
    </form>
    <?php endif; ?>

    <?php if ($can_price): ?>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/price-group')?>"
          class="row" style="gap:.35rem;align-items:flex-end">
      <?=$csrf()?>
      <label class="field"><span class="label">Price group</span>
        <select class="select" name="price_group_id">
          <option value="">Standard rates</option>
          <?php foreach ($groups as $g): ?>
            <option value="<?=(int)$g->id?>" <?=(int)$user->price_group_id === (int)$g->id ? 'selected' : ''?>>
              <?=htmlspecialchars($g->name)?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
      <button class="btn btn-secondary btn-sm" type="submit">Save</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<?php
// Credentials panel. Passwords stay one-way hashes with reset-only controls;
// the transaction PIN is the one credential staff can read back, because the
// operator asked for exactly that: it also lives in an AES-256-GCM envelope
// (users.pin_cipher), the reveal is POST-only, gated on users.edit and
// audited per use. PINs chosen before the envelope existed are hash-only and
// are reported as unreadable rather than guessed at.
$pin_set = !empty($user->pin_hash);
$pin_locked = !empty($user->pin_locked_until) && strtotime($user->pin_locked_until.' UTC') > time();
$pin_revealable = $pin_set && !empty($user->pin_cipher);
?>
<?php if (!$self && $can_edit): ?>
<div class="card mb-4">
  <h3 style="font-size:1rem;font-weight:600" class="mb-1">Credentials</h3>
  <p class="muted text-xs mb-3">
    Passwords are stored as one-way hashes and can only be reset — never displayed. The security PIN is
    stored encrypted as well, so staff can read it back when a customer asks; every reveal is recorded in
    the audit log with who asked.
  </p>

  <div class="row mb-3" style="gap:1.25rem;flex-wrap:wrap">
    <div>
      <div class="muted text-xs">Security PIN</div>
      <div class="text-sm">
        <?php if (!$pin_set): ?>
          Not set
        <?php elseif ($pin_locked): ?>
          Set · <span style="color:var(--color-danger,#dc2626)">locked until
            <?=htmlspecialchars(date('H:i', strtotime($user->pin_locked_until.' UTC')))?> UTC</span>
        <?php else: ?>
          Set<?php if ((int)$user->pin_failed_attempts > 0): ?>
            · <?=(int)$user->pin_failed_attempts?> failed attempt<?=(int)$user->pin_failed_attempts === 1 ? '' : 's'?>
          <?php endif; ?>
        <?php endif; ?>
      </div>
      <?php if ($pin_set && !$pin_revealable): ?>
        <div class="muted text-xs">Set before encrypted PIN history was kept — readable only after the customer sets their next PIN.</div>
      <?php endif; ?>
    </div>
    <div>
      <div class="muted text-xs">Two-factor</div>
      <div class="text-sm"><?=((int)$user->mfa_enabled === 1) ? 'Enabled' : 'Not enabled'?></div>
    </div>
    <div>
      <div class="muted text-xs">Email verified</div>
      <div class="text-sm"><?=$user->email_verified_at ? 'Yes' : 'No'?></div>
    </div>
  </div>

  <div class="row" style="gap:.5rem;flex-wrap:wrap">
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/password-reset')?>" style="margin:0">
      <?=$csrf()?>
      <button class="btn btn-secondary btn-sm" type="submit">Email a password-reset link</button>
    </form>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/force-logout')?>" style="margin:0"
          data-confirm="Revoke refresh tokens for this account?" >
      <?=$csrf()?>
      <button class="btn btn-secondary btn-sm" type="submit">Force logout</button>
    </form>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/revoke-keys')?>" style="margin:0"
          data-confirm="Revoke every API key for this account?" >
      <?=$csrf()?>
      <button class="btn btn-secondary btn-sm" type="submit">Revoke API keys</button>
    </form>

    <?php if ($pin_set): ?>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/pin-reveal')?>" style="margin:0" data-confirm="Reveal this customer's security PIN? The reveal is recorded in the audit log.">
      <?=$csrf()?>
      <button class="btn btn-secondary btn-sm" type="submit">Reveal security PIN</button>
    </form>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/pin-reset')?>" style="margin:0" data-confirm="Clear this customer's security PIN? They must set a new one before their next PIN-protected action.">
      <?=$csrf()?>
      <input type="hidden" name="reason" value="Reset from the customer file">
      <button class="btn btn-secondary btn-sm" type="submit">Clear security PIN</button>
    </form>
    <?php endif; ?>

    <?php if ($pin_locked): ?>
    <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/pin-unlock')?>" style="margin:0">
      <?=$csrf()?>
      <button class="btn btn-secondary btn-sm" type="submit">Lift PIN lockout</button>
    </form>
    <?php endif; ?>
  </div>
</div>
<?php endif; ?>

<?php if ($can_impersonate && !$self && $user->status === 'ACTIVE' && $user->role === 'CUSTOMER'): ?>
<div class="card mb-4" style="border-color:var(--color-warning,#f59e0b)">
  <h3 style="font-size:1rem;font-weight:600" class="mb-1">Customer impersonation</h3>
  <p class="muted text-xs mb-3">
    Sign in to this customer's dashboard. The session is audited, expires after 30 minutes, never reveals
    credentials and never allows credential changes. Use only with customer authorization or an approved
    support reason.
  </p>
  <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/impersonate')?>">
    <?=$csrf()?>
    <fieldset class="mb-2" style="border:0;padding:0;margin:0">
      <legend class="label" style="padding:0">Access level</legend>
      <label class="row text-xs mb-1" style="gap:.5rem;align-items:flex-start">
        <input type="radio" name="mode" value="READ_ONLY" checked style="margin-top:.2rem">
        <span><strong>Read-only</strong> — view their dashboard to diagnose an issue. Every write action is blocked.</span>
      </label>
      <label class="row text-xs" style="gap:.5rem;align-items:flex-start">
        <input type="radio" name="mode" value="FULL_ACCESS" style="margin-top:.2rem">
        <span><strong>Full access</strong> — act on their behalf: place orders, open tickets, spend their wallet.
          Every action is recorded against you in the audit trail.</span>
      </label>
    </fieldset>
    <label class="field mb-2"><span class="label">Support reason</span>
      <textarea class="input" name="reason" rows="2" minlength="5" maxlength="500" required
                placeholder="Ticket reference and issue being investigated"></textarea>
    </label>
    <label class="row text-xs mb-3" style="gap:.5rem;align-items:flex-start">
      <input type="checkbox" name="confirm" value="1" required style="margin-top:.2rem">
      <span>I understand this switches my effective identity to this customer and I must use the warning banner to return to my staff account.</span>
    </label>
    <button class="btn btn-warning btn-sm" type="submit">Start impersonation</button>
  </form>
</div>
<?php endif; ?>

<?php if ($can_money): ?>
<?php if (!empty($can_choose_currency) && !empty($currency_choices)): ?>
<div class="card mb-4">
  <h3 style="font-size:1rem;font-weight:600" class="mb-1">Wallet currency</h3>
  <p class="muted text-xs mb-3">
    One-time choice, available only while the wallet is empty and has never moved money.
    Once set, purchases charge in <?=htmlspecialchars(marvy_base_currency())?> converted at the rate pinned on each movement.
  </p>
  <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/wallet-currency')?>" class="row" style="gap:.5rem;align-items:flex-end;flex-wrap:wrap">
    <?=$csrf()?>
    <label class="field"><span class="label">Hold the wallet in</span>
      <select class="select" name="currency" required>
        <?php foreach ($currency_choices as $c): ?>
          <option value="<?=htmlspecialchars($c->code)?>" <?=strtoupper((string)$c->code)===strtoupper((string)$user->wallet->currency)?'selected':''?>>
            <?=htmlspecialchars($c->code)?> — <?=htmlspecialchars((string)$c->name)?>
          </option>
        <?php endforeach; ?>
      </select>
    </label>
    <button class="btn btn-primary btn-sm" type="submit">Set currency</button>
  </form>
</div>
<?php endif; ?>
<div class="card mb-4">
  <h3 style="font-size:1rem;font-weight:600" class="mb-1">Adjust wallet</h3>
  <p class="muted text-xs mb-3">
    Recorded in the ledger against your account. A debit cannot take the balance below zero.
    <?php if (strtoupper((string)$user->wallet->currency) !== strtoupper(marvy_base_currency())): ?>
    This wallet holds <strong><?=htmlspecialchars($user->wallet->currency)?></strong> —
    adjustments are entered in the wallet's own currency, not <?=htmlspecialchars(marvy_base_currency())?>.
    <?php endif; ?>
  </p>
  <form method="post" action="<?=site_url('admin/customers/'.$user->public_id.'/adjust')?>"
        class="row" style="gap:.5rem;align-items:flex-end;flex-wrap:wrap">
    <?=$csrf()?>
    <input type="hidden" name="nonce" value="<?=htmlspecialchars($nonce)?>">
    <label class="field"><span class="label">Direction</span>
      <select class="select" name="direction">
        <option value="CREDIT">Credit — add funds</option>
        <option value="DEBIT">Debit — take funds back</option>
      </select>
    </label>
    <label class="field"><span class="label">Amount (<?=htmlspecialchars($user->wallet->currency ?? marvy_base_currency())?>)</span>
      <input class="input mono" type="number" name="amount" step="0.01" min="0.01" required
             placeholder="0.00" style="max-width:9rem">
    </label>
    <label class="field" style="flex:1;min-width:14rem"><span class="label">Reason (required)</span>
      <input class="input" name="reason" required maxlength="255"
             placeholder="e.g. goodwill for failed order WX1234">
    </label>
    <button class="btn btn-primary btn-sm" type="submit">Apply adjustment</button>
  </form>
</div>
<?php endif; ?>

<div class="card mb-4">
  <h3 style="font-size:1rem;font-weight:600" class="mb-3">Recent wallet movements</h3>
  <?php if (empty($movements)): ?>
    <p class="muted text-sm">No wallet activity yet.</p>
  <?php else: ?>
  <div class="overflow-x-auto">
    <table class="table">
      <thead><tr><th>When</th><th>Type</th><th class="text-right">Amount</th>
                 <th class="text-right">Balance after</th><th>Note</th></tr></thead>
      <tbody>
      <?php foreach ($movements as $m): ?>
        <tr>
          <td class="text-xs muted whitespace-nowrap"><?=htmlspecialchars(date('M j, H:i', strtotime($m->created_at)))?></td>
          <td class="text-xs"><?=htmlspecialchars(DashboardStats::transaction_label($m))?></td>
          <td class="text-right mono <?=$m->direction === 'CREDIT' ? 'text-green-600' : ''?>">
            <?=$m->direction === 'CREDIT' ? '+' : '−'?><?=marvy_money($m->amount, $m->currency)?>
          </td>
          <td class="text-right mono muted"><?=marvy_money($m->balance_after, $m->currency)?></td>
          <td class="text-xs muted"><?=htmlspecialchars((string)($m->note ?? ''))?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php if (!empty($can_view_earnings)): ?>
<div class="card mb-4">
  <div class="row justify-between mb-3" style="align-items:center">
    <h3 style="font-size:1rem;font-weight:600" class="mb-0">Affiliate &amp; earnings history</h3>
    <a class="btn btn-ghost btn-sm" href="<?=site_url('admin/payouts?status=&user_id='.(int)$user->id)?>">All payouts for this user →</a>
  </div>
  <?php $es = $earnings_summary; ?>
  <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(9rem,1fr));gap:.75rem" class="mb-3">
    <div><div class="muted text-xs">Available</div><div class="mono font-medium"><?=marvy_money($es['available'])?></div></div>
    <div><div class="muted text-xs">Pending</div><div class="mono font-medium"><?=marvy_money($es['pending'])?></div></div>
    <div><div class="muted text-xs">Locked</div><div class="mono font-medium"><?=marvy_money($es['locked'])?></div></div>
    <div><div class="muted text-xs">Paid out</div><div class="mono font-medium"><?=marvy_money($es['paid'])?></div></div>
    <div><div class="muted text-xs">Total earned</div><div class="mono font-medium"><?=marvy_money($es['total_earned'])?></div></div>
    <div><div class="muted text-xs">Reversed</div><div class="mono font-medium"><?=marvy_money($es['reversed'])?></div></div>
  </div>

  <div class="row" style="gap:1rem;flex-wrap:wrap;align-items:flex-start">
    <div style="flex:1;min-width:18rem">
      <h4 class="text-xs muted mb-2" style="text-transform:uppercase;letter-spacing:.05em">Recent earnings</h4>
      <?php if (empty($earning_rows)): ?>
        <p class="muted text-sm">No earnings recorded.</p>
      <?php else: ?>
        <table class="table">
          <tbody>
          <?php foreach ($earning_rows as $e): ?>
            <tr>
              <td class="text-xs muted whitespace-nowrap"><?=htmlspecialchars(date('M j, H:i', strtotime($e->created_at)))?></td>
              <td class="text-xs"><?=htmlspecialchars(ucfirst(strtolower($e->source)))?></td>
              <td class="text-right mono text-xs"><?=marvy_money($e->amount, $e->currency ?? null)?></td>
              <td><span class="badge badge-default"><?=htmlspecialchars($e->status)?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
    <div style="flex:1;min-width:18rem">
      <h4 class="text-xs muted mb-2" style="text-transform:uppercase;letter-spacing:.05em">Recent payout requests</h4>
      <?php if (empty($payout_rows)): ?>
        <p class="muted text-sm">No withdrawal requests.</p>
      <?php else: ?>
        <table class="table">
          <tbody>
          <?php foreach ($payout_rows as $p): ?>
            <tr>
              <td class="text-xs muted whitespace-nowrap"><?=htmlspecialchars(date('M j, H:i', strtotime($p->requested_at)))?></td>
              <td class="text-xs"><?=htmlspecialchars(str_replace('_',' ',$p->method))?></td>
              <td class="text-right mono text-xs"><?=marvy_money($p->amount, $p->currency ?? null)?></td>
              <td><span class="badge badge-default"><?=htmlspecialchars($p->status)?></span></td>
              <td><a class="text-xs" href="<?=site_url('admin/payouts/'.$p->public_id)?>">View →</a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="row" style="gap:.75rem;flex-wrap:wrap;align-items:flex-start">
  <div class="card" style="flex:1;min-width:20rem">
    <h3 style="font-size:1rem;font-weight:600" class="mb-3">Recent SMM orders</h3>
    <?php if (empty($orders)): ?>
      <p class="muted text-sm">No orders.</p>
    <?php else: ?>
      <table class="table">
        <tbody>
        <?php foreach ($orders as $o): ?>
          <tr>
            <td><a class="mono text-xs" href="<?=site_url('admin/orders/'.$o->public_id)?>"><?=htmlspecialchars($o->public_id)?></a></td>
            <td class="text-xs"><?=htmlspecialchars((string)($o->service_name ?? ''))?></td>
            <td class="text-right mono text-xs"><?=marvy_money($o->charge, $o->currency ?? null)?></td>
            <td><span class="<?=DashboardStats::status_badge($o->status)?>"><?=htmlspecialchars($o->status)?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>

  <div class="card" style="flex:1;min-width:20rem">
    <h3 style="font-size:1rem;font-weight:600" class="mb-3">Recent service purchases</h3>
    <?php if (empty($services)): ?>
      <p class="muted text-sm">No VTU, number, identity or gift card purchases.</p>
    <?php else: ?>
      <table class="table">
        <tbody>
        <?php foreach ($services as $s): ?>
          <tr>
            <td class="mono text-xs"><?=htmlspecialchars($s->public_id)?></td>
            <td class="text-xs"><?=htmlspecialchars((string)$s->service_domain)?> · <?=htmlspecialchars((string)$s->service_type)?></td>
            <td class="text-right mono text-xs"><?=marvy_money($s->amount, $s->currency ?? null)?></td>
            <td><span class="<?=DashboardStats::status_badge($s->status)?>"><?=htmlspecialchars($s->status)?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    <?php endif; ?>
  </div>
</div>
