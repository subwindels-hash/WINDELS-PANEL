<section class="max-w-4xl mx-auto px-4 py-12"><h1 class="text-3xl font-bold"><?=htmlspecialchars($title ?? 'Post')?></h1></section>
